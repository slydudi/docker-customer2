# jaeger-thrift

This module builds a jar containing auto-generated Thrift classes
for the IDL defined in https://github.com/jaegertracing/jaeger-idl.

It uses Thrift compiler from a Docker image, thus requires a working Docker installation.
